package br.edu.ifsp.spo.java.cards;

import br.edu.ifsp.spo.java.cards.nucleo.Jogo;

import java.text.MessageFormat;

public class App {

    public static void main(String[] args) {
//        Carta carta1 = new Carta(Naipe.ESPADAS, Valor.AS);
//        Carta carta2 = new Carta(Naipe.COPAS, Valor.DEZ);

        Jogo vinteUm = new Jogo();
        vinteUm.play();
//        System.out.println(vinteUm);

//        Baralho baralho = new Baralho();
//
//        Carta carta = baralho.tirarCarta();
//
//        System.out.println(carta);
//
//        System.out.println(MessageFormat.format("Cartas restantes no baralho: {0}", baralho.cartasRestantes()));
    }
}